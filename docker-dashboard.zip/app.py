from flask import Flask, render_template, redirect, url_for, request
import docker

app = Flask(__name__)
client = docker.from_env()

@app.route('/')
def index():
    containers = client.containers.list(all=True)
    return render_template('index.html', containers=containers)

@app.route('/start/<container_id>')
def start(container_id):
    container = client.containers.get(container_id)
    container.start()
    return redirect(url_for('index'))

@app.route('/stop/<container_id>')
def stop(container_id):
    container = client.containers.get(container_id)
    container.stop()
    return redirect(url_for('index'))

@app.route('/restart/<container_id>')
def restart(container_id):
    container = client.containers.get(container_id)
    container.restart()
    return redirect(url_for('index'))

@app.route('/logs/<container_id>')
def logs(container_id):
    container = client.containers.get(container_id)
    log_output = container.logs(tail=100).decode('utf-8')
    return f"<pre>{log_output}</pre>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
